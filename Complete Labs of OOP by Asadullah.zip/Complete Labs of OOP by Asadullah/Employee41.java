public class Employee41 {
    private String name ;
    private int joinYear;
    private double salary;
    private String addree;

    public Employee41(String name, double salary, int joinYear, String addree) {
        this.name = name;
        this.salary = salary;
        this.joinYear = joinYear;
        this.addree = addree;
    }

    public String getName() {
        return name;
    }

    public int getJoinYear() {
        return joinYear;
    }

    public double getSalary() {
        return salary;
    }

    public String getAddree() {
        return addree;
    }
}
