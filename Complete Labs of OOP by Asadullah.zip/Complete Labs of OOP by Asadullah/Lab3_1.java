

public class Lab3_1 {
    public static void main(String[] args) {
        String firstName = "Asadullah";
        String lastName = "Prizado";
        System.out.println(firstName.concat(" ").concat(lastName));
    }
}
