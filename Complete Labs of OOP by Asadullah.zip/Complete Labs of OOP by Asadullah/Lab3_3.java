public class Lab3_3 {
    public static void main(String[] args) {
        String o= "The quick brown fox jumps over the lazy dog.";
        o=o.replace("fox","cat");
        System.out.println(o);
    }
}
