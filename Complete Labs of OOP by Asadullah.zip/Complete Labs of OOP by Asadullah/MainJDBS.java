public class MainJDBS {
    public static void main(String[] args) {
        DBSC.add("Asad","Sukkur");
    }
}
