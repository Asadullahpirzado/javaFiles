import org.w3c.dom.ls.LSOutput;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Main{
    public static void main(String[] args) {


        try(
                Scanner input =  new Scanner(System.in);


                FileWriter write1 = new FileWriter("asad"+"txt", true)){
            String name = input.next();
            write1.write(" \n Asadullah");
            write1.write("\n");
            write1.write(input.next());
          Scanner reader = new Scanner( new File("asad.txt"));
          while (reader.hasNextLine()){
              System.out.println(reader.hasNextLine());
          }

        } catch (IOException e) {
            System.out.println("Error :");
        }

    }
}