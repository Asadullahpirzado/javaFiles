CREATE DATABASE hotelmanagementsystem;
USE hotelmanagementsystem;

-- Customer Table
CREATE TABLE customer (
    customer_id INT AUTO_INCREMENT PRIMARY KEY,
    document_type VARCHAR(50) NOT NULL,
    document_number VARCHAR(50) NOT NULL,
    name VARCHAR(100) NOT NULL,
    gender ENUM('Male', 'Female') NOT NULL,
    country VARCHAR(50) NOT NULL,
    room_number VARCHAR(10) NOT NULL,
    check_in_time DATETIME NOT NULL,
    deposit DECIMAL(10, 2) NOT NULL,
    checkout_time DATETIME,
    UNIQUE (document_type, document_number),
    FOREIGN KEY (room_number) REFERENCES room(room_number)
);

-- Room Table
CREATE TABLE room (
    room_number VARCHAR(10) PRIMARY KEY,
    availability ENUM('Available', 'Occupied') NOT NULL,
    cleaning_status ENUM('Cleaned', 'Dirty') NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    bed_type ENUM('Single Bed', 'Double Bed') NOT NULL
);

-- Employee Table
CREATE TABLE employee (
    employee_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    age INT NOT NULL,
    gender ENUM('Male', 'Female') NOT NULL,
    job VARCHAR(50) NOT NULL,
    salary DECIMAL(10, 2) NOT NULL,
    phone VARCHAR(15) NOT NULL,
    email VARCHAR(100) NOT NULL,
    aadhar VARCHAR(12) UNIQUE NOT NULL
);

-- Driver Table
CREATE TABLE driver (
    driver_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    age INT NOT NULL,
    gender ENUM('Male', 'Female') NOT NULL,
    company VARCHAR(50) NOT NULL,
    car_model VARCHAR(50) NOT NULL,
    availability ENUM('Available', 'Busy') NOT NULL,
    location VARCHAR(100) NOT NULL
);

-- Department Table
CREATE TABLE department (
    department_name VARCHAR(50) PRIMARY KEY,
    budget DECIMAL(15, 2) NOT NULL
);

-- Login Table
CREATE TABLE login (
    username VARCHAR(50) PRIMARY KEY,
    password VARCHAR(50) NOT NULL
);
INSERT INTO room (room_number, availability, cleaning_status, price, bed_type) VALUES
('101', 'Available', 'Cleaned', 1500.00, 'Single Bed'),
('102', 'Occupied', 'Dirty', 2000.00, 'Double Bed'),
('103', 'Available', 'Cleaned', 1800.00, 'Single Bed');
INSERT INTO customer (document_type, document_number, name, gender, country, room_number, check_in_time, deposit, checkout_time) VALUES
('Passport', 'A1234567', 'John Doe', 'Male', 'USA', '102', '2025-05-10 14:00:00', 1000.00, NULL),
('ID Card', 'B7654321', 'Alice Smith', 'Female', 'UK', '103', '2025-05-11 12:00:00', 1200.00, NULL);
INSERT INTO employee (name, age, gender, job, salary, phone, email, aadhar) VALUES
('David Johnson', 30, 'Male', 'Manager', 35000.00, '03001234567', 'david@example.com', '123456789012'),
('Sara Khan', 25, 'Female', 'Receptionist', 20000.00, '03007654321', 'sara@example.com', '987654321098');

INSERT INTO driver (name, age, gender, company, car_model, availability, location) VALUES
('Ali Ahmed', 35, 'Male', 'City Cabs', 'Toyota Corolla', 'Available', 'Main Road'),
('Fatima Noor', 29, 'Female', 'GoDrive', 'Honda Civic', 'Busy', 'Airport');
INSERT INTO department (department_name, budget) VALUES
('Housekeeping', 500000.00),
('Front Desk', 300000.00),
('Transport', 200000.00);
INSERT INTO login (username, password) VALUES
('admin', '123')
;




