public class Abstract {
    public static void main(String[] args) {
        Dog dog = new Dog();
        dog.makeSound();
    }
}
