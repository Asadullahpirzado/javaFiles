public abstract class Animal {
    abstract public void makeSound();
}
