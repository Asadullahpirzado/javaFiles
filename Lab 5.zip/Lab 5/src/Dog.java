public class Dog extends Animal{
    public void makeSound(){
        System.out.println("ha ha ");
    }
}
