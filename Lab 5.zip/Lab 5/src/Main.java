//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
       int num= SumOfEvenANDOdd.Even(79);
        System.out.println(num);
        num=SumOfEvenANDOdd.Odd(15);
        System.out.println(num);
        System.out.println("Multiple of Factorial"+ Factorial.factorial(2,3));
         }

    }
