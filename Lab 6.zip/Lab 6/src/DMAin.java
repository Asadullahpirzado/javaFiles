public class DMAin {
    public static void main(String[] args) {
        DATABASE.addStudent("ALI3","PIR","AD@gamil.com","54754577","fgfhgfsh","BSCS","2024","3.4","123");
        DATABASE.viewStudentInfo();

    }
}
