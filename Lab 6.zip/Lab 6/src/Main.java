public class Main {
    public static void main(String[] args) {
        Point p1 = new Point(5, 5);
        Point p2 = new Point(10, 10);
        Point p3 = new Point(15, 15);

        Circle c1 = new Circle(5, p1);
        Circle c2 = new Circle(7, p2);

        Rectangle r1 = new Rectangle(10, 6, p3);
        Rectangle r2 = new Rectangle(4, 8, new Point(2, 2));

        ShapeArray shapes = new ShapeArray(10);

        shapes.addShape(c1);
        shapes.addShape(c2);
        shapes.addShape(r1);
        shapes.addShape(r2);

        System.out.println("All Shapes:");
        System.out.println(shapes);

        System.out.println("Number of Circles: " + shapes.getCircleCounter());
        System.out.println("Average Rectangle Area: " + shapes.getAvgRectArea());

        System.out.println("Displaying Only Rectangles:");
        shapes.displayRectsInfo();

        shapes.removeAllRect();

        System.out.println("Shapes after removing all rectangles:");
        System.out.println(shapes);
    }
}
