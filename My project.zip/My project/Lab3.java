import java.util.Scanner;

public class Lab3{
public static void main(String[] args) {
    System.out.println("Hello world");
    Scanner input = new Scanner(System.in);
    System.out.println("Enter the name ");
    String name = input.nextLine();




    input.close();

}
}