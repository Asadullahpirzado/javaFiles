public class Course {
    private String course_id;
    private String   course_name;
    private double credit_hours;
    public void setCourse(String course_id,String course_name, double credit_hours){
        this.course_id=course_id;
        this.course_name=course_name;
        this.credit_hours=credit_hours;

    }

    public String getCourse_id() {
        return this.course_id;
    }

    public String getCourse_name() {
        return this.course_name;
    }

    public double getCredit_hours() {
        return this.credit_hours;
    }
}
