import java.sql.*;

public class CourseDBS {
    public void addCourse(Course course) throws SQLException {
        String sql = "INSERT INTO Courses (course_id, course_name, credit_hours) VALUES (?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, course.getCourse_id());
            pstmt.setString(2, course.getCourse_name());
            pstmt.setDouble(3, course.getCredit_hours());
            pstmt.executeUpdate();
        }
    }

    public Course getCourseById(String courseId) throws SQLException {
        String sql = "SELECT * FROM Courses WHERE course_id=?";
        Course course = null;

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, courseId);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                course = new Course();
                course.setCourse(rs.getString("course_id"), rs.getString("course_name"), rs.getDouble("credit_hours"));
            }
        }
        return course;
    }
}
