import java.util.Scanner;
import java.sql.SQLException;

public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        StudentDBS studentDBS = new StudentDBS();

        while (true) {
            System.out.println("\n=== Student Management System ===");
            System.out.println("1. Manage Student Records");
            System.out.println("2. Search Student Record");
            System.out.println("3. Exit");
            System.out.print("Enter your choice: ");
            int num = input.nextInt();

            if (num == 1) {
                System.out.println("1. Update Student");
                System.out.println("2. Delete Student");
                System.out.println("3. Add Student");
                System.out.print("Enter your choice: ");
                int num1 = input.nextInt();

                if (num1 == 1) {
                    System.out.print("Enter Student ID to update: ");
                    String studentId = input.next();
                    try {
                        Student student = studentDBS.getStudentById(studentId);
                        if (student != null) {
                            System.out.print("Enter new name: ");
                            String name = input.next();
                            System.out.print("Enter new age: ");
                            int age = input.nextInt();
                            System.out.print("Enter new gender (Male/Female): ");
                            String gender = input.next();
                            System.out.print("Enter new email: ");
                            String email = input.next();
                            System.out.print("Enter new phone number: ");
                            String phone = input.next();

                            student.setName(name);
                            student.setAge(age);
                            student.setGender(gender);
                            student.setEmail(email);
                            student.setPhone_number(phone);

                            studentDBS.updateStudent(student);
                            System.out.println("Student updated successfully.");
                        } else {
                            System.out.println("Student not found.");
                        }
                    } catch (SQLException e) {
                        System.out.println("Error updating student: " + e.getMessage());
                    }
                } else if (num1 == 2) {
                    System.out.print("Enter Student ID to delete: ");
                    String studentId = input.next();
                    try {
                        studentDBS.deleteStudent(studentId);
                        System.out.println("Student deleted successfully.");
                    } catch (SQLException e) {
                        System.out.println("Error deleting student: " + e.getMessage());
                    }
                } else if (num1 == 3) {
                    System.out.print("Enter Student ID: ");
                    String studentId = input.next();
                    System.out.print("Enter name: ");
                    String name = input.next();
                    System.out.print("Enter age: ");
                    int age = input.nextInt();
                    System.out.print("Enter gender (Male/Female): ");
                    String gender = input.next();
                    System.out.print("Enter email: ");
                    String email = input.next();
                    System.out.print("Enter phone number: ");
                    String phone = input.next();

                    Student newStudent = new Student(studentId, name, age, gender, email, phone,null);
                    try {
                        studentDBS.addStudent(newStudent);
                        System.out.println("Student added successfully.");
                    } catch (SQLException e) {
                        System.out.println("Error adding student: " + e.getMessage());
                    }
                } else {
                    System.out.println("Invalid input.");
                }
            } else if (num == 2) {
                System.out.print("Enter Student ID to search: ");
                String studentId = input.next();
                try {
                    Student student = studentDBS.getStudentById(studentId);
                    if (student != null) {
                        System.out.println("\nStudent Found:");
                        System.out.println("ID: " + student.getStudent_id());
                        System.out.println("Name: " + student.getName());
                        System.out.println("Age: " + student.getAge());
                        System.out.println("Gender: " + student.getGender());
                        System.out.println("Email: " + student.getEmail());
                        System.out.println("Phone: " + student.getPhone_number());
                    } else {
                        System.out.println("Student not found.");
                    }
                } catch (SQLException e) {
                    System.out.println("Error searching student: " + e.getMessage());
                }
            } else if (num == 3) {
                System.out.println("Exiting program...");
                break;
            } else {
                System.out.println("Invalid input. Try again.");
            }
        }

        input.close();
    }
}
