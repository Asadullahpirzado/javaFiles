public class Student {
    private String student_id;
    private String name;
    private int age;
    private String gender;
    private String email;
    private String phone_number;
    private Course course;  // New field to store the course
    public Student(String student_id, String name,int age, String gender, String email, String phone_number, Course course){
        setinfo(student_id,name,age, gender,email,phone_number,null);
    }
    public void setinfo(String student_id, String name, int age, String gender, String email, String phone_number, Course course) {
        this.student_id = student_id;
        this.name = name;
        this.email = email;
        this.phone_number = phone_number;
        this.course = course;

        if (age > 0 && (gender.equalsIgnoreCase("Female") || gender.equalsIgnoreCase("Male"))) {
            this.age = age;
            this.gender = gender;
        } else {
            System.out.println("Invalid age or gender.");
        }
    }

    public void setStudent_id(String student_id) {
        this.student_id = student_id;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPhone_number(String phone_number) {
        this.phone_number = phone_number;
    }

    public void setStudentId(String studentId) { this.student_id = studentId; }
    public String getStudent_id() { return this.student_id; }
    public String getName() { return this.name; }
    public int getAge() { return this.age; }
    public String getGender() { return this.gender; }
    public String getEmail() { return this.email; }
    public String getPhone_number() { return this.phone_number; }
    public Course getCourse() { return this.course; }  // New getter
}
