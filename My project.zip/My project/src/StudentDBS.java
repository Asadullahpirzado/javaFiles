import java.sql.*;

public class StudentDBS {
    // Add Student to Database
    public void addStudent(Student student) throws SQLException {
        String sql = "INSERT INTO Students (student_id, name, age, gender, email, phone_number) VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            pstmt.setString(1, student.getStudent_id());
            pstmt.setString(2, student.getName());
            pstmt.setInt(3, student.getAge());
            pstmt.setString(4, student.getGender());
            pstmt.setString(5, student.getEmail());
            pstmt.setString(6, student.getPhone_number()); // Changed to String

            pstmt.executeUpdate();
        }
    }

    // Update Student Data
    public void updateStudent(Student student) throws SQLException {
        String sql = "UPDATE Students SET name=?, age=?, gender=?, email=?, phone_number=? WHERE student_id=?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, student.getName());
            pstmt.setInt(2, student.getAge());
            pstmt.setString(3, student.getGender());
            pstmt.setString(4, student.getEmail());
            pstmt.setString(5, student.getPhone_number());
            pstmt.setString(6, student.getStudent_id());

            pstmt.executeUpdate();
        }
    }

    // Delete Student
    public void deleteStudent(String studentId) throws SQLException {
        String sql = "DELETE FROM Students WHERE student_id=?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, studentId);
            pstmt.executeUpdate();
        }
    }

    // Search Student by ID
    public Student getStudentById(String studentId) throws SQLException {
        String sql = "SELECT * FROM Students WHERE student_id=?";
        Student student = null;

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, studentId);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                student = new Student(
                        rs.getString("student_id"),
                        rs.getString("name"),
                        rs.getInt("age"),
                        rs.getString("gender"),
                        rs.getString("email"),
                        rs.getString("phone_number")
                );
            }
        }
        return student;
    }
}
