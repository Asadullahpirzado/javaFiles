public class Dog implements Interface{
    @Override
    public void OMSound() {
        System.out.println("Omi");
    }

    @Override
    public void Sound(int i) {
        System.out.println("woof");
    }

    public static void main(String[] args) {
        Dog Fahad = new Dog();
        Fahad.OMSound();
        Fahad.Sound(6);
    }
}
