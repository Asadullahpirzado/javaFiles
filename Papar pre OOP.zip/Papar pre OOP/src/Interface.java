public interface  Interface {
    void OMSound();
     void Sound(int i);
}
