import java.sql.*;
import java.text.*;
import java.util.*;

public class Main {
    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            // Create instances of UserDAO and ExpenseDAO
            UserDAO userDAO = new UserDAO();
            ExpenseDAO expenseDAO = new ExpenseDAO();

            // Step 1: Take user input for creating a new user
            System.out.println("Enter your name:");
            String name = scanner.nextLine();

            System.out.println("Enter your email:");
            String email = scanner.nextLine();

            System.out.println("Enter your password:");
            String password = scanner.nextLine();

            System.out.println("Choose your user mode (Single, Mom, Dad):");
            String userMode = scanner.nextLine();

            // Add the user to the database
            try {
                userDAO.createUser(name, email, password, userMode);
                System.out.println("User created successfully!");
            } catch (SQLException e) {
                // Catching the SQLException if the user creation fails
                System.err.println("Error creating user: " + e.getMessage());
                return; // Exiting early in case of error
            }

            // Further code for handling user-related operations (e.g., fetching user, adding expenses) can go here...
        } catch (Exception e) {
            // Catching any general exception that might occur during execution
            e.printStackTrace();
        }
    }
}