import java.util.Scanner;

public class Admin extends User {
    // Admin-specific attributes (e.g., adminId, role)
    private String adminId;
    public static String capitalizeFirstLetter(String str) {
        if (str == null || str.isEmpty()) {
            return str; // Return as is if null or empty
        }
        return str.substring(0, 1).toUpperCase() + str.substring(1).toLowerCase();
    }
    // Existing Admin class constructor and methods...

    // Modify the login method to accept userId and password as arguments
    public boolean login(int userId, String password) {
        // Logic for validating the Admin's login credentials (could be from a database)
    Scanner input = new Scanner(System.in);
        Student s1 = new Student();
        Teacher t1 = new Teacher();
        Course c1 = new Course();
        Enrollment e1 = new Enrollment();
        System.out.println("Enter Admin ID");
        int adminID = input.nextInt();
        input.nextLine();
        System.out.println("Enter Admin Password");
        String adminPassword = input.nextLine();
        if (adminID==2 && adminPassword.equals("asad")) {
            System.out.println("Login Successful");
            System.out.println("Welcome Admin");
            char flag = 'y';
            while (flag=='y') {
                System.out.println("What do you want to do?");
                System.out.println("1. Add Student");
                System.out.println("2. Add Teacher");
                System.out.println("3. Add Course");
                System.out.println("4. Add Enrollment");
                System.out.println("5. View Students");
                System.out.println("6. View Teachers");
                System.out.println("7. View Courses");
                System.out.println("8. View Enrollments");
                System.out.println("9. Update Student");
                System.out.println("10. Update Teacher");
                System.out.println("11. Update Course");
                System.out.println("12. Delete Student");
                System.out.println("13. Delete Teacher");
                System.out.println("14. Delete Course");
                System.out.println("15. Delete Enrollment");
                System.out.println("16. Search Student");
                System.out.println("17. Search Teacher");
                System.out.println("18. Search Course");
                System.out.println("19. Search Enrollment");
                System.out.println("20. Assign Subject to teacher");
                System.out.println("21. Search  Teacher that assign subject to teach");
                System.out.println("22. View all the  Teachers that are assigned to  teach");
                System.out.println("23. Delete the teacher that have assigned subject to teach ");

                int choice = input.nextInt();
                switch (choice) {
                    case 1: {
                        System.out.println("Enter the first name of  Student ");
                        setFirstName(input.nextLine());
                        input.nextLine();
                        System.out.println("Enter the last name of  Student ");
                        setLastName(input.nextLine());
                        System.out.println("Enter the email of  Student ");
                        setEmail(input.nextLine());
                        System.out.println("Enter the phoneNumber of  Student ");
                        setPhone(input.nextLine());
                        System.out.println("Enter the DOB of  Student ");
                        setDOB(input.nextLine());
                        System.out.println("Enter the address of  Student ");
                        setAddress(input.nextLine());
                        System.out.println("Enter the Department of  Student ");
                        setDepartment(input.nextLine());
                        System.out.println("Enter the Batch of  Student ");
                        s1.setBatch(input.nextLine());
                        System.out.println("Enter the GPA of  Student ");
                        s1.setGPA(input.nextLine());
                        System.out.println("Enter the Password of  Student ");
                        setPassword(input.nextLine());
                        StudentDBS.addStudent(getFirstName(), getLastName(), getEmail(), getPhone(), getDOB(), getAddress(), getDepartment(), s1.getBatch(), s1.getGPA(), getPassword());
                        break;
                    }
                    case 2: {
                        input.nextLine();
                        System.out.println("Enter the first name of Teacher: ");

                        setFirstName(input.nextLine());

                        System.out.println("Enter the last name of Teacher: ");
                        setLastName(input.nextLine());

                        System.out.println("Enter the email of Teacher: ");
                        setEmail(input.nextLine());

                        System.out.println("Enter the phone number of Teacher: ");
                        setPhone(input.nextLine());

                        System.out.println("Enter the department of Teacher: ");
                        setDepartment(input.nextLine());

                        System.out.println("Enter the hire date of Teacher (YYYY-MM-DD): ");
                        t1.setHireDate(input.nextLine());

                        System.out.println("Enter the salary of Teacher: ");
                        t1.setSalary(input.nextDouble());
                        input.nextLine(); // Consume newline

                        System.out.println("Enter the designation of Teacher: ");
                        t1.setDesignation(input.nextLine());

                        System.out.println("Enter the qualification of Teacher: ");
                        t1.setQualification(input.nextLine());
                        System.out.println("Enter the password : ");
                        setPassword(input.nextLine());
                        TeacherDBS.addTeacher(getFirstName(), getLastName(), getEmail(), getPhone(), getDepartment(), t1.getHireDate(), t1.getSalary(), t1.getDesignation(), t1.getQualification(), getPassword());
                        break;
                    }
                    case 3: {
                        System.out.println("Enter the  name of Course: ");
                        c1.setCourseName(input.nextLine());
                        input.nextLine();
                        System.out.println("Enter the Credits of  Course: ");
                        c1.setCourseCredits(input.nextInt());
                        input.nextLine();
                        System.out.println("Enter the department of Course: ");
                        c1.setDepartment(input.nextLine());

                        CourseDBS.addCourse(c1.getCourseName(), c1.getCourseCredits(), c1.getDepartment());
                        break;
                    }
                    case 4: {
                        System.out.println("Enter the Student ID for Enrollment: ");
                        e1.setStudentID(input.nextInt());
                        System.out.println("Enter the Course ID for Enrollment: ");
                        e1.setCourseID(input.nextInt());
                        System.out.println("Enter the Status (\"Active\", \"Completed\", or \"Dropped\") for Enrollment: ");
                        e1.setStatus(input.nextLine());
                        EnrollmentDBS.addEnrollment(e1.getStudentID(), e1.getCourseID(), e1.getStatus());
                        break;
                    }
                    case 5: {
                        StudentDBS.viewAllStudents();
                        break;
                    }
                    case 6: {
                        TeacherDBS.viewAllTeachers();
                        break;
                    }
                    case 7: {
                        CourseDBS.viewAllCourses();
                        break;
                    }
                    case 8: {
                        EnrollmentDBS.viewAllEnrollments();
                        break;
                    }
                    case 9: {
                        System.out.println("Enter the Student ID for Update: ");
                        int studentID = input.nextInt();
                        input.nextLine();
                        System.out.println("Enter the Email : ");
                        setEmail(input.nextLine());
                        // input.nextLine();
                        System.out.println("Enter the Phone number : ");
                        setPhone(input.nextLine());
                        //
                        // input.nextLine();
                        System.out.println("Enter the Address : ");
                        setAddress(input.nextLine());
                        System.out.println("Enter the GPA : ");
                        s1.setGPA(input.nextLine());
                        System.out.println("Enter the Password : ");
                        setPassword(input.nextLine());
                        StudentDBS.updateStudent(studentID,getEmail(),getPhone(),getAddress(), s1.getGPA(), getPassword());

                        break;
                    }
                    case 10: {
                        System.out.println("Enter the Teacher ID for Update: ");
                        int teacherID = input.nextInt();
                        input.nextLine();
                        System.out.println("Enter the Email : ");
                        setEmail(input.nextLine());
                        System.out.println("Enter the Phone number : ");
                        setPhone(input.nextLine());
                        System.out.println("Enter the department  : ");
                        setDepartment(input.nextLine());
                        System.out.println("Enter the Salary : ");
                        t1.setSalary(input.nextDouble());
                        input.nextLine();
                        System.out.println("Enter the designation : ");
                        t1.setDesignation(input.nextLine());
                        System.out.println("Enter the password : ");
                        setPassword(input.nextLine());
                        TeacherDBS.updateTeacher(teacherID, getEmail(), getPhone(), getDepartment(), t1.getSalary(), t1.getDesignation(), getPassword());
                        break;
                    }
                    case 11: {
                        System.out.println("Enter the Course ID for Update: ");
                        int courseID = input.nextInt();
                        input.nextLine();
                        System.out.println("Enter the course name : ");
                        c1.setCourseName(input.nextLine());
                        System.out.println("Enter the course credit : ");
                        c1.setCourseCredits(input.nextInt());
                        input.nextLine();
                        System.out.println("Enter the department : ");
                        c1.setDepartment(input.nextLine());
                        CourseDBS.updateCourse(courseID, c1.getCourseName(), c1.getCourseCredits(), c1.getDepartment());
                        break;
                    }
                    case 12: {
                        System.out.println("Enter the Student ID for delete: ");
                        int studentID = input.nextInt();
                        StudentDBS.deleteStudent(studentID);
                        break;
                    }
                    case 13: {
                        System.out.println("Enter the Teacher ID for delete: ");
                        int teacherID = input.nextInt();
                        TeacherDBS.deleteTeacher(teacherID);
                        break;
                    }
                    case 14: {
                        System.out.println("Enter the Course ID for delete: ");
                        int courseID = input.nextInt();
                        CourseDBS.deleteCourse(courseID);
                        break;
                    }
                    case 15: {
                        System.out.println("Enter the Student ID for delete Enrollment: ");
                        int studentID = input.nextInt();
                        System.out.println("Enter the Course ID for delete Enrollment: ");
                        int courseID = input.nextInt();
                        EnrollmentDBS.deleteEnrollment(studentID, courseID);
                        break;
                    }
                    case 16: {
                        System.out.println("Enter the Student ID for Search : ");
                        int studentID = input.nextInt();
                        StudentDBS.searchStudent(studentID);
                        break;
                    }
                    case 17: {
                        System.out.println("Enter the Teacher ID for Search : ");
                        int teacherID = input.nextInt();
                        TeacherDBS.searchTeacher(teacherID);
                        break;
                    }
                    case 18: {
                        System.out.println("Enter the Course  ID for Search : ");
                        int courseID = input.nextInt();
                        CourseDBS.searchCourse(courseID);
                        break;
                    }
                    case 19: {
                        System.out.println("Enter the Student ID for Searching Enrollment: ");
                        int studentID = input.nextInt();
                        System.out.println("Enter the Course ID for Searching Enrollment: ");
                        int courseID = input.nextInt();
                        EnrollmentDBS.searchEnrollment(studentID, courseID);
                        break;
                    }
                    case 20: {
                        System.out.println("Enter the Teacher ID for assign course: ");
                        int teacherID = input.nextInt();
                        System.out.println("Enter the Course ID for assign course: ");
                        int courseID = input.nextInt();

                        TeachesDBS.assignCourseToTeacher(teacherID, courseID);
                        break;
                    }
                    case 21: {
                        System.out.println("Enter the Teacher ID ");
                        int teacherID = input.nextInt();
                        TeachesDBS.viewTeacherAssignments(teacherID);
                        break;

                    }
                    case 22: {
                        TeachesDBS.viewAllAssignments();
                        break;
                    }
                    case 23: {
                        System.out.println("Enter the Course ID ");
                        int courseID = input.nextInt();
                        System.out.println("Enter the Teacher ID ");
                        int teacherID = input.nextInt();

                        TeachesDBS.deleteAssignment(teacherID, courseID);
                        break;
                    }
                    default: {
                        System.out.println("Invalid Operation");
                    }

                }
                System.out.println("do you want to continue? (Y/N)");
                flag= input.next().charAt(0);
            }





            input.close();

            System.out.println("Admin login successful");
            return true;
        }
        System.out.println("Invalid Admin credentials");
        return false;
    }
}
