import java.sql.*;
import java.util.Scanner;

public class CourseDBS {
    // Database credentials
    private static final String URL = "jdbc:mysql://localhost:3306/StudentManagement";
    private static final String USER = "root";  // Change if your MySQL has a different username
    private static final String PASSWORD = "asad";  // Enter your MySQL password if set

    // Method to add a new course
    public static void addCourse(String courseName, int credits , String department) {
        String query = "INSERT INTO Course (CourseName, Credits , department) VALUES (?, ?,?)";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, courseName);
            pstmt.setInt(2, credits);
            pstmt.setString(3, department);
            pstmt.executeUpdate();
            System.out.println("✅ Course added successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to update course details
    public static void updateCourse(int courseId, String courseName, int credits , String department) {
        String query = "UPDATE Course SET CourseName = ?, Credits = ? , department = ? WHERE CourseID = ?";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, courseName);
            pstmt.setInt(2, credits);
            pstmt.setString(3, department);
            int rowsUpdated = pstmt.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("✅ Course updated successfully!");
            } else {
                System.out.println("⚠️ Course not found!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to delete a course
    public static void deleteCourse(int courseId) {
        String query = "DELETE FROM Course WHERE CourseID = ?";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setInt(1, courseId);
            int rowsDeleted = pstmt.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("✅ Course deleted successfully!");
            } else {
                System.out.println("⚠️ Course not found!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to search for a course
    public static void searchCourse(int courseId) {
        String query = "SELECT * FROM Course WHERE CourseID = ?";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setInt(1, courseId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                System.out.println("\n📘 Course Found:");
                System.out.println("ID: " + rs.getInt("CourseID"));
                System.out.println("Name: " + rs.getString("CourseName"));
                System.out.println("Credits: " + rs.getInt("Credits"));
                System.out.println("Department: " + rs.getString("Department"));
            } else {
                System.out.println("⚠️ Course not found!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public static void viewAllCourses() {
        String sql = "SELECT * FROM Course";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            ResultSet rs = pstmt.executeQuery();

            System.out.println("List of All Courses:");
            System.out.println("--------------------------------------------------------------");
            System.out.printf("%-5s %-30s %-10s %-20s\n",
                    "ID", "Course Name", "Credits", "Department");
            System.out.println("--------------------------------------------------------------");

            while (rs.next()) {
                System.out.printf("%-5d %-30s %-10d %-20s\n",
                        rs.getInt("CourseID"),
                        rs.getString("CourseName"),
                        rs.getInt("Credits"),
                        rs.getString("Department"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


}
