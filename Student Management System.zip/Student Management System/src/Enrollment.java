public class Enrollment {
   private int studentID;
   private int courseID;
   private String status; // "Active", "Completed", or "Dropped"

   public void setStudentID(int studentID) {
      this.studentID = studentID;
   }

   public void setCourseID(int courseID) {
      this.courseID = courseID;
   }

   public void setStatus(String status) {
      this.status = status;
   }

   // Getters
   public int getStudentID() { return studentID; }
   public int getCourseID() { return courseID; }
   public String getStatus() { return status; }
}
