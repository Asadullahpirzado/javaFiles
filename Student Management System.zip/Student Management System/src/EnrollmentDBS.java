import java.sql.*;
import java.util.Scanner;

public class EnrollmentDBS {
    // Database credentials
    private static final String URL = "jdbc:mysql://localhost:3306/StudentManagement";
    private static final String USER = "root";  // Change if your MySQL has a different username
    private static final String PASSWORD = "asad";  // Enter your MySQL password if set

    // Method to add a new enrollment
    public static void addEnrollment(int studentId, int courseId, String status) {
        String query = "INSERT INTO Enrollment (StudentID, CourseID, Status) VALUES (?, ?, ?)";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setInt(1, studentId);
            pstmt.setInt(2, courseId);
            pstmt.setString(3, status);
            pstmt.executeUpdate();
            System.out.println("✅ Enrollment added successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to update enrollment status
    public static void updateEnrollment(int studentId, int courseId, String status) {
        String query = "UPDATE Enrollment SET Status = ? WHERE StudentID = ? AND CourseID = ?";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, status);
            pstmt.setInt(2, studentId);
            pstmt.setInt(3, courseId);
            int rowsUpdated = pstmt.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("✅ Enrollment updated successfully!");
            } else {
                System.out.println("⚠️ Enrollment not found!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to delete an enrollment
    public static void deleteEnrollment(int studentId, int courseId) {
        String query = "DELETE FROM Enrollment WHERE StudentID = ? AND CourseID = ?";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setInt(1, studentId);
            pstmt.setInt(2, courseId);
            int rowsDeleted = pstmt.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("✅ Enrollment deleted successfully!");
            } else {
                System.out.println("⚠️ Enrollment not found!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to search for an enrollment
    public static void searchEnrollment(int studentId, int courseId) {
        String query = "SELECT * FROM Enrollment WHERE StudentID = ? AND CourseID = ?";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setInt(1, studentId);
            pstmt.setInt(2, courseId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                System.out.println("\n📚 Enrollment Found:");
                System.out.println("Student ID: " + rs.getInt("StudentID"));
                System.out.println("Course ID: " + rs.getInt("CourseID"));
                System.out.println("Status: " + rs.getString("Status") + "\n");
            } else {
                System.out.println("⚠️ Enrollment not found!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public static void viewAllEnrollments() {
        String sql = "SELECT e.StudentID, s.FirstName, s.LastName, e.CourseID, c.CourseName, e.Status " +
                "FROM Enrollment e " +
                "JOIN Student s ON e.StudentID = s.StudentID " +
                "JOIN Course c ON e.CourseID = c.CourseID";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            ResultSet rs = pstmt.executeQuery();

            System.out.println("List of All Enrollments:");
            System.out.println("--------------------------------------------------------------------------------------------");
            System.out.printf("%-10s %-20s %-10s %-30s %-15s\n",
                    "StudentID", "Student Name", "CourseID", "Course Name", "Status");
            System.out.println("--------------------------------------------------------------------------------------------");

            while (rs.next()) {
                System.out.printf("%-10d %-20s %-10d %-30s %-15s\n",
                        rs.getInt("StudentID"),
                        rs.getString("FirstName") + " " + rs.getString("LastName"),
                        rs.getInt("CourseID"),
                        rs.getString("CourseName"),
                        rs.getString("Status"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


}
