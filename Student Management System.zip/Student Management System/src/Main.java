import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Admin admin = new Admin();
        Student student = new Student();
        Teacher teacher = new Teacher();
        System.out.println("Enter the role ");
        Scanner input = new Scanner(System.in);
        String role = input.nextLine();
        switch(role){
            case "admin":{
                //admin.login();
                break;

            }
            case "student":{
                System.out.println("Enter Student ID");
                int studentID = input.nextInt();
                input.nextLine();
                System.out.println("Enter Password");
                String password = input.nextLine();
                StudentDBS.login(studentID, password);
                break;
            }
            case "teacher":{
                System.out.println("Enter Teacher ID");
                int teacherID = input.nextInt();
                input.nextLine();
                System.out.println("Enter Password");
                String password = input.nextLine();
                TeacherDBS.login(teacherID, password);
                break;
            }
            default:{
                System.out.println("Invalid Role");
            }

        }


    }
}