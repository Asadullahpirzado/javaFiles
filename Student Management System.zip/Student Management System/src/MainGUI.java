import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class MainGUI {
    private static JFrame frame;
    private static CardLayout cardLayout;
    private static JPanel mainPanel;
    private static final String LOGIN = "LOGIN";
    private static final String ADMIN = "ADMIN";
    private static final String STUDENT = "STUDENT";
    private static final String TEACHER = "TEACHER";

    private static Connection connection;

    public static void main(String[] args) {
        initializeDatabase();
        SwingUtilities.invokeLater(() -> createAndShowGUI());
    }

    private static void initializeDatabase() {
        String URL = "jdbc:mysql://localhost:3306/StudentManagement"; // Replace with your actual DB name
        String USER = "root";
        String PASSWORD = "asad"; // Replace with your MySQL password

        try {
            connection = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println("Database connected successfully!"); // Debugging
        } catch (SQLException e) {
            e.printStackTrace(); // Debugging in console
            JOptionPane.showMessageDialog(null, "Database Error: " + e.getMessage());
            System.exit(1);
        }
    }

    private static void createAndShowGUI() {
        frame = new JFrame("School Management System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);

        cardLayout = new CardLayout();
        mainPanel = new JPanel(cardLayout);

        mainPanel.add(createLoginPanel(), LOGIN);
        mainPanel.add(createAdminPanel(), ADMIN);
        mainPanel.add(createStudentPanel(), STUDENT);
        mainPanel.add(createTeacherPanel(), TEACHER);

        frame.add(mainPanel);
        frame.setVisible(true);
    }
    private static JPanel createTeacherPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.add(new JLabel("Teacher Dashboard", SwingConstants.CENTER), BorderLayout.CENTER);
        panel.add(createLogoutButton(), BorderLayout.SOUTH);
        return panel;
    }

    private static JPanel createStudentPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.add(new JLabel("Student Dashboard", SwingConstants.CENTER), BorderLayout.CENTER);
        panel.add(createLogoutButton(), BorderLayout.SOUTH);
        return panel;
    }

    private static JPanel createLoginPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);

        JComboBox<String> roleCombo = new JComboBox<>(new String[]{"Admin", "Student", "Teacher"});
        JTextField idField = new JTextField(15);
        JPasswordField passwordField = new JPasswordField(15);
        JButton loginButton = new JButton("Login");

        // Layout
        gbc.gridx = 0; gbc.gridy = 0;
        panel.add(new JLabel("Role:"), gbc);
        gbc.gridx = 1;
        panel.add(roleCombo, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        panel.add(new JLabel("ID:"), gbc);
        gbc.gridx = 1;
        panel.add(idField, gbc);

        gbc.gridx = 0; gbc.gridy = 2;
        panel.add(new JLabel("Password:"), gbc);
        gbc.gridx = 1;
        panel.add(passwordField, gbc);

        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 2;
        panel.add(loginButton, gbc);

        loginButton.addActionListener(e -> {
            String role = (String) roleCombo.getSelectedItem();
            int  id = Integer.parseInt(idField.getText());
            String password = new String(passwordField.getPassword());

            try {

                if (authenticateUser(role, id, password)) {
                    switch (role.toLowerCase()) {
                        case "admin": cardLayout.show(mainPanel, ADMIN); break;
                        case "student":{
                            int studentId = id;  // From login
                            mainPanel.add(createStudentPanel(studentId), STUDENT);
                            cardLayout.show(mainPanel, STUDENT);
                            break;}
                        case "teacher": cardLayout.show(mainPanel, TEACHER); break;
                    }
                } else {
                    JOptionPane.showMessageDialog(panel, "Invalid credentials");
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(panel, "ID must be a number");
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(panel, "Database error: " + ex.getMessage());
            }
        });

        return panel;
    }
    private static void showStudentManagement() {
        JDialog dialog = new JDialog(frame, "Student Management", true);
        dialog.setSize(800, 600);

        JPanel panel = new JPanel(new BorderLayout());
        JTable studentTable = new JTable(getStudentData());
        JScrollPane scrollPane = new JScrollPane(studentTable);

        JPanel buttonPanel = new JPanel();
        JButton addButton = new JButton("Add Student");
        JButton updateButton = new JButton("Update Student");
        JButton deleteButton = new JButton("Delete Student");

        addButton.addActionListener(e -> showStudentForm(dialog, studentTable, -1));
        updateButton.addActionListener(e -> {
            int selectedRow = studentTable.getSelectedRow();
            if(selectedRow == -1) {
                JOptionPane.showMessageDialog(dialog, "Please select a student");
                return;
            }
            int studentId = (int) studentTable.getValueAt(selectedRow, 0);
            showStudentForm(dialog, studentTable, studentId);
        });
        deleteButton.addActionListener(e -> {
            int selectedRow = studentTable.getSelectedRow();
            if(selectedRow == -1) {
                JOptionPane.showMessageDialog(dialog, "Please select a student");
                return;
            }
            int studentId = (int) studentTable.getValueAt(selectedRow, 0);
            StudentDBS.deleteStudent(studentId);
            studentTable.setModel(getStudentData());
        });

        buttonPanel.add(addButton);
        buttonPanel.add(updateButton);
        buttonPanel.add(deleteButton);

        panel.add(scrollPane, BorderLayout.CENTER);
        panel.add(buttonPanel, BorderLayout.SOUTH);
        dialog.add(panel);
        dialog.setVisible(true);
    }

    private static void showStudentForm(JDialog parent, JTable table, int studentId) {
        JDialog dialog = new JDialog(parent, studentId == -1 ? "Add Student" : "Update Student", true);
        dialog.setSize(400, 500);
        JPanel panel = new JPanel(new GridLayout(0, 2, 5, 5));

        JTextField firstNameField = new JTextField();
        JTextField lastNameField = new JTextField();
        JTextField emailField = new JTextField();
        JTextField phoneField = new JTextField();
        JTextField dobField = new JTextField();
        JTextField addressField = new JTextField();
        JTextField deptField = new JTextField();
        JTextField batchField = new JTextField();
        JTextField gpaField = new JTextField();
        JPasswordField passwordField = new JPasswordField();

        if(studentId != -1) {
            // Load existing data
            try (PreparedStatement pstmt = connection.prepareStatement("SELECT * FROM Student WHERE StudentID = ?")) {
                pstmt.setInt(1, studentId);
                ResultSet rs = pstmt.executeQuery();
                if(rs.next()) {
                    firstNameField.setText(rs.getString("FirstName"));
                    lastNameField.setText(rs.getString("LastName"));
                    emailField.setText(rs.getString("Email"));
                    phoneField.setText(rs.getString("PhoneNumber"));
                    dobField.setText(rs.getString("DateOfBirth"));
                    addressField.setText(rs.getString("Address"));
                    deptField.setText(rs.getString("Department"));
                    batchField.setText(rs.getString("Batch"));
                    gpaField.setText(rs.getString("GPA"));
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }

        panel.add(new JLabel("First Name:"));
        panel.add(firstNameField);
        panel.add(new JLabel("Last Name:"));
        panel.add(lastNameField);
        panel.add(new JLabel("Email:"));
        panel.add(emailField);
        panel.add(new JLabel("Phone:"));
        panel.add(phoneField);
        panel.add(new JLabel("DOB (YYYY-MM-DD):"));
        panel.add(dobField);
        panel.add(new JLabel("Address:"));
        panel.add(addressField);
        panel.add(new JLabel("Department:"));
        panel.add(deptField);
        panel.add(new JLabel("Batch:"));
        panel.add(batchField);
        panel.add(new JLabel("GPA:"));
        panel.add(gpaField);
        panel.add(new JLabel("Password:"));
        panel.add(passwordField);

        JButton submitButton = new JButton(studentId == -1 ? "Add Student" : "Update Student");
        submitButton.addActionListener(e -> {
            try {
                if(studentId == -1) {
                    StudentDBS.addStudent(
                            firstNameField.getText(),
                            lastNameField.getText(),
                            emailField.getText(),
                            phoneField.getText(),
                            dobField.getText(),
                            addressField.getText(),
                            deptField.getText(),
                            batchField.getText(),
                            gpaField.getText(),
                            new String(passwordField.getPassword())
                    );
                } else {
                    StudentDBS.updateStudent(
                            studentId,
                            emailField.getText(),
                            phoneField.getText(),
                            addressField.getText(),
                            gpaField.getText(),
                            new String(passwordField.getPassword())
                    );
                }
                table.setModel(getStudentData());
                dialog.dispose();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(dialog, "Error: " + ex.getMessage());
            }
        });

        dialog.add(panel, BorderLayout.CENTER);
        dialog.add(submitButton, BorderLayout.SOUTH);
        dialog.setVisible(true);
    }



    // Updated table models
    private static DefaultTableModel getStudentData() {
        String[] columns = {"ID", "First Name", "Last Name", "Email", "Phone", "DOB", "Address", "Department", "Batch", "GPA"};
        DefaultTableModel model = new DefaultTableModel(columns, 0);

        try (Statement stmt = connection.createStatement()) {
            ResultSet rs = stmt.executeQuery("SELECT * FROM Student");
            while (rs.next()) {
                model.addRow(new Object[] {
                        rs.getInt("StudentID"),
                        rs.getString("FirstName"),
                        rs.getString("LastName"),
                        rs.getString("Email"),
                        rs.getString("PhoneNumber"),
                        rs.getDate("DateOfBirth"),
                        rs.getString("Address"),
                        rs.getString("Department"),
                        rs.getString("Batch"),
                        rs.getDouble("GPA")
                });
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return model;
    }

    private static boolean authenticateUser(String role, int id, String password)
            throws SQLException, NumberFormatException {

        String table = switch (role.toLowerCase()) {
            case "admin" -> "admin";
            case "student" -> "student";
            case "teacher" -> "teacher";
            default -> throw new IllegalArgumentException("Invalid role");
        };


        String sql = "SELECT * FROM " + table + " WHERE "+Admin.capitalizeFirstLetter(table)+"id = ? AND password = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            pstmt.setString(2, password);
            ResultSet rs = pstmt.executeQuery();
            return rs.next();
        }
    }

    private static JPanel createAdminPanel() {
        JPanel panel = new JPanel(new BorderLayout());

        JPanel buttonPanel = new JPanel(new GridLayout(1, 3, 10, 10));
        JButton manageStudents = new JButton("Manage Students");
        JButton manageTeachers = new JButton("Manage Teachers");
        JButton manageCourses = new JButton("Manage Courses");

        manageStudents.addActionListener(e -> showStudentManagement());
        manageTeachers.addActionListener(e -> showTeacherManagement());
        manageCourses.addActionListener(e -> showCourseManagement());

        buttonPanel.add(manageStudents);
        buttonPanel.add(manageTeachers);
        buttonPanel.add(manageCourses);

        panel.add(buttonPanel, BorderLayout.NORTH);
        panel.add(createLogoutButton(), BorderLayout.SOUTH);

        return panel;
    }

    private static void showTeacherManagement() {
        JDialog dialog = new JDialog(frame, "Teacher Management", true);
        dialog.setSize(1000, 600);

        JPanel panel = new JPanel(new BorderLayout());
        JTable teacherTable = new JTable(getTeacherData());
        JScrollPane scrollPane = new JScrollPane(teacherTable);

        JPanel buttonPanel = new JPanel(new GridLayout(1, 4, 5, 5));
        JButton addButton = new JButton("Add Teacher");
        JButton updateButton = new JButton("Update Teacher");
        JButton deleteButton = new JButton("Delete Teacher");
        JButton assignCourseButton = new JButton("Assign Course");

        addButton.addActionListener(e -> showTeacherForm(dialog, teacherTable, -1));
        updateButton.addActionListener(e -> {
            int selectedRow = teacherTable.getSelectedRow();
            if(selectedRow == -1) {
                JOptionPane.showMessageDialog(dialog, "Please select a teacher");
                return;
            }
            int teacherId = (int) teacherTable.getValueAt(selectedRow, 0);
            showTeacherForm(dialog, teacherTable, teacherId);
        });

        deleteButton.addActionListener(e -> {
            int selectedRow = teacherTable.getSelectedRow();
            if(selectedRow == -1) {
                JOptionPane.showMessageDialog(dialog, "Please select a teacher");
                return;
            }
            int teacherId = (int) teacherTable.getValueAt(selectedRow, 0);
            int confirm = JOptionPane.showConfirmDialog(dialog,
                    "Are you sure you want to delete this teacher?", "Confirm Delete",
                    JOptionPane.YES_NO_OPTION);
            if(confirm == JOptionPane.YES_OPTION) {
                TeacherDBS.deleteTeacher(teacherId);
                teacherTable.setModel(getTeacherData());
            }
        });

        assignCourseButton.addActionListener(e -> showAssignCourseDialog(dialog));

        buttonPanel.add(addButton);
        buttonPanel.add(updateButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(assignCourseButton);

        panel.add(scrollPane, BorderLayout.CENTER);
        panel.add(buttonPanel, BorderLayout.SOUTH);
        dialog.add(panel);
        dialog.setVisible(true);
    }

    private static void showTeacherForm(JDialog parent, JTable table, int teacherId) {
        JDialog dialog = new JDialog(parent, teacherId == -1 ? "Add Teacher" : "Update Teacher", true);
        dialog.setSize(400, 500);
        JPanel panel = new JPanel(new GridLayout(0, 2, 5, 5));

        JTextField firstNameField = new JTextField();
        JTextField lastNameField = new JTextField();
        JTextField emailField = new JTextField();
        JTextField phoneField = new JTextField();
        JTextField deptField = new JTextField();
        JTextField hireDateField = new JTextField();
        JTextField salaryField = new JTextField();
        JTextField designationField = new JTextField();
        JTextField qualificationField = new JTextField();
        JPasswordField passwordField = new JPasswordField();

        if(teacherId != -1) {
            try (PreparedStatement pstmt = connection.prepareStatement(
                    "SELECT * FROM Teacher WHERE TeacherID = ?")) {
                pstmt.setInt(1, teacherId);
                ResultSet rs = pstmt.executeQuery();
                if(rs.next()) {
                    firstNameField.setText(rs.getString("FirstName"));
                    lastNameField.setText(rs.getString("LastName"));
                    emailField.setText(rs.getString("Email"));
                    phoneField.setText(rs.getString("PhoneNumber"));
                    deptField.setText(rs.getString("Department"));
                    hireDateField.setText(rs.getString("HireDate"));
                    salaryField.setText(String.valueOf(rs.getDouble("Salary")));
                    designationField.setText(rs.getString("Designation"));
                    qualificationField.setText(rs.getString("Qualification"));
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }

        panel.add(new JLabel("First Name:"));
        panel.add(firstNameField);
        panel.add(new JLabel("Last Name:"));
        panel.add(lastNameField);
        panel.add(new JLabel("Email:"));
        panel.add(emailField);
        panel.add(new JLabel("Phone:"));
        panel.add(phoneField);
        panel.add(new JLabel("Department:"));
        panel.add(deptField);
        panel.add(new JLabel("Hire Date (YYYY-MM-DD):"));
        panel.add(hireDateField);
        panel.add(new JLabel("Salary:"));
        panel.add(salaryField);
        panel.add(new JLabel("Designation:"));
        panel.add(designationField);
        panel.add(new JLabel("Qualification:"));
        panel.add(qualificationField);
        panel.add(new JLabel("Password:"));
        panel.add(passwordField);

        JButton submitButton = new JButton(teacherId == -1 ? "Add Teacher" : "Update Teacher");
        submitButton.addActionListener(e -> {
            try {
                double salary = Double.parseDouble(salaryField.getText());

                if(teacherId == -1) {
                    TeacherDBS.addTeacher(
                            firstNameField.getText(),
                            lastNameField.getText(),
                            emailField.getText(),
                            phoneField.getText(),
                            deptField.getText(),
                            hireDateField.getText(),
                            salary,
                            designationField.getText(),
                            qualificationField.getText(),
                            new String(passwordField.getPassword())
                    );
                } else {
                    TeacherDBS.updateTeacher(
                            teacherId,
                            emailField.getText(),
                            phoneField.getText(),
                            deptField.getText(),
                            salary,
                            designationField.getText(),
                            new String(passwordField.getPassword())
                    );
                }
                table.setModel(getTeacherData());
                dialog.dispose();
                JOptionPane.showMessageDialog(parent, "Operation completed successfully!");
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(dialog, "Invalid salary format");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(dialog, "Error: " + ex.getMessage());
            }
        });

        dialog.add(panel, BorderLayout.CENTER);
        dialog.add(submitButton, BorderLayout.SOUTH);
        dialog.setVisible(true);
    }

    private static void showAssignCourseDialog(JDialog parent) {
        JDialog dialog = new JDialog(parent, "Assign Course to Teacher", true);
        dialog.setSize(400, 200);
        JPanel panel = new JPanel(new GridLayout(3, 2, 5, 5));

        JTextField teacherIdField = new JTextField();
        JTextField courseIdField = new JTextField();

        panel.add(new JLabel("Teacher ID:"));
        panel.add(teacherIdField);
        panel.add(new JLabel("Course ID:"));
        panel.add(courseIdField);

        JButton submitButton = new JButton("Assign Course");
        submitButton.addActionListener(e -> {
            try {
                int teacherId = Integer.parseInt(teacherIdField.getText());
                int courseId = Integer.parseInt(courseIdField.getText());
                TeachesDBS.assignCourseToTeacher(teacherId, courseId);
                JOptionPane.showMessageDialog(dialog, "Course assigned successfully!");
                dialog.dispose();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(dialog, "Invalid ID format");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(dialog, "Error: " + ex.getMessage());
            }
        });

        dialog.add(panel, BorderLayout.CENTER);
        dialog.add(submitButton, BorderLayout.SOUTH);
        dialog.setVisible(true);
    }

    private static DefaultTableModel getTeacherData() {
        String[] columns = {"ID", "First Name", "Last Name", "Email", "Phone", "Department",
                "Hire Date", "Salary", "Designation", "Qualification"};
        DefaultTableModel model = new DefaultTableModel(columns, 0);

        try (Statement stmt = connection.createStatement()) {
            ResultSet rs = stmt.executeQuery("SELECT * FROM Teacher");
            while (rs.next()) {
                model.addRow(new Object[] {
                        rs.getInt("TeacherID"),
                        rs.getString("FirstName"),
                        rs.getString("LastName"),
                        rs.getString("Email"),
                        rs.getString("PhoneNumber"),
                        rs.getString("Department"),
                        rs.getDate("HireDate"),
                        rs.getDouble("Salary"),
                        rs.getString("Designation"),
                        rs.getString("Qualification")
                });
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return model;
    }

    private static void showCourseManagement() {
        JDialog dialog = new JDialog(frame, "Course Management", true);
        dialog.setSize(800, 600);

        JPanel panel = new JPanel(new BorderLayout());
        JTable courseTable = new JTable(getCourseData());
        JScrollPane scrollPane = new JScrollPane(courseTable);

        JPanel buttonPanel = new JPanel(new GridLayout(1, 3, 5, 5));
        JButton addButton = new JButton("Add Course");
        JButton updateButton = new JButton("Update Course");
        JButton deleteButton = new JButton("Delete Course");

        addButton.addActionListener(e -> showCourseForm(dialog, courseTable, -1));
        updateButton.addActionListener(e -> {
            int selectedRow = courseTable.getSelectedRow();
            if(selectedRow == -1) {
                JOptionPane.showMessageDialog(dialog, "Please select a course");
                return;
            }
            int courseId = (int) courseTable.getValueAt(selectedRow, 0);
            showCourseForm(dialog, courseTable, courseId);
        });

        deleteButton.addActionListener(e -> {
            int selectedRow = courseTable.getSelectedRow();
            if(selectedRow == -1) {
                JOptionPane.showMessageDialog(dialog, "Please select a course");
                return;
            }
            int courseId = (int) courseTable.getValueAt(selectedRow, 0);
            int confirm = JOptionPane.showConfirmDialog(dialog,
                    "Are you sure you want to delete this course?", "Confirm Delete",
                    JOptionPane.YES_NO_OPTION);
            if(confirm == JOptionPane.YES_OPTION) {
                CourseDBS.deleteCourse(courseId);
                courseTable.setModel(getCourseData());
            }
        });

        buttonPanel.add(addButton);
        buttonPanel.add(updateButton);
        buttonPanel.add(deleteButton);

        panel.add(scrollPane, BorderLayout.CENTER);
        panel.add(buttonPanel, BorderLayout.SOUTH);
        dialog.add(panel);
        dialog.setVisible(true);
    }

    private static void showCourseForm(JDialog parent, JTable table, int courseId) {
        JDialog dialog = new JDialog(parent, courseId == -1 ? "Add Course" : "Update Course", true);
        dialog.setSize(400, 300);
        JPanel panel = new JPanel(new GridLayout(0, 2, 5, 5));

        JTextField nameField = new JTextField();
        JTextField creditsField = new JTextField();
        JTextField deptField = new JTextField();

        if(courseId != -1) {
            try (PreparedStatement pstmt = connection.prepareStatement(
                    "SELECT * FROM Course WHERE CourseID = ?")) {
                pstmt.setInt(1, courseId);
                ResultSet rs = pstmt.executeQuery();
                if(rs.next()) {
                    nameField.setText(rs.getString("CourseName"));
                    creditsField.setText(String.valueOf(rs.getInt("CourseCredits")));
                    deptField.setText(rs.getString("Department"));
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }

        panel.add(new JLabel("Course Name:"));
        panel.add(nameField);
        panel.add(new JLabel("Credits:"));
        panel.add(creditsField);
        panel.add(new JLabel("Department:"));
        panel.add(deptField);

        JButton submitButton = new JButton(courseId == -1 ? "Add Course" : "Update Course");
        submitButton.addActionListener(e -> {
            try {
                int credits = Integer.parseInt(creditsField.getText());

                if(courseId == -1) {
                    CourseDBS.addCourse(
                            nameField.getText(),
                            credits,
                            deptField.getText()
                    );
                } else {
                    CourseDBS.updateCourse(
                            courseId,
                            nameField.getText(),
                            credits,
                            deptField.getText()
                    );
                }
                table.setModel(getCourseData());
                dialog.dispose();
                JOptionPane.showMessageDialog(parent, "Operation completed successfully!");
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(dialog, "Invalid credits format");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(dialog, "Error: " + ex.getMessage());
            }
        });

        dialog.add(panel, BorderLayout.CENTER);
        dialog.add(submitButton, BorderLayout.SOUTH);
        dialog.setVisible(true);
    }

    private static DefaultTableModel getCourseData() {
        DefaultTableModel model = new DefaultTableModel(new String[]{"Course ID", "Course Name", "Credits"}, 0);

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/StudentManagement", "root", "asad");
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT CourseID, CourseName, Credits FROM course")) {

            while (rs.next()) {
                int id = rs.getInt("CourseID");
                String name = rs.getString("CourseName");
                int credits = rs.getInt("Credits"); // Ensure this column exists in your DB
                model.addRow(new Object[]{id, name, credits});
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error fetching course data:\n" + ex.getMessage());
        }

        return model;
    }



    private static JPanel createStudentPanel(int studentId) {
        JPanel panel = new JPanel(new BorderLayout());

        // Add enrollment button at the top
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton enrollButton = new JButton("Enroll in New Course");
        enrollButton.addActionListener(e -> showCourseEnrollmentDialog(studentId));
        topPanel.add(enrollButton);

        // Existing tabbed pane setup
        JTabbedPane tabbedPane = new JTabbedPane();
        // ... [existing tab setup code]

        panel.add(topPanel, BorderLayout.NORTH);
        panel.add(tabbedPane, BorderLayout.CENTER);
        panel.add(createLogoutButton(), BorderLayout.SOUTH);

        //JPanel panel = new JPanel(new BorderLayout());
      //  JTabbedPane tabbedPane = new JTabbedPane();

        // Personal Information Panel
        JPanel infoPanel = new JPanel(new GridLayout(0, 2, 10, 10));
        addStudentInfo(studentId, infoPanel);

        // Enrollments Panel
        JPanel enrollmentPanel = new JPanel(new BorderLayout());
        JTable enrollmentTable = new JTable(getStudentEnrollments(studentId));
        enrollmentPanel.add(new JScrollPane(enrollmentTable), BorderLayout.CENTER);

        // Assigned Teachers Panel
        JPanel teachersPanel = new JPanel(new BorderLayout());
        JTable teachersTable = new JTable(getStudentTeachers(studentId));
        teachersPanel.add(new JScrollPane(teachersTable), BorderLayout.CENTER);

        tabbedPane.addTab("Personal Info", infoPanel);
        tabbedPane.addTab("Enrollments", enrollmentPanel);
        tabbedPane.addTab("Assigned Teachers", teachersPanel);

        panel.add(tabbedPane, BorderLayout.CENTER);
        panel.add(createLogoutButton(), BorderLayout.SOUTH);
        return panel;
    }

    private static void addStudentInfo(int studentId, JPanel panel) {
        try (PreparedStatement pstmt = connection.prepareStatement(
                "SELECT * FROM Student WHERE StudentID = ?")) {
            pstmt.setInt(1, studentId);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                addInfoRow(panel, "Student ID:", rs.getString("StudentID"));
                addInfoRow(panel, "Name:", rs.getString("FirstName") + " " + rs.getString("LastName"));
                addInfoRow(panel, "Email:", rs.getString("Email"));
                addInfoRow(panel, "Department:", rs.getString("Department"));
                addInfoRow(panel, "Batch:", rs.getString("Batch"));
                addInfoRow(panel, "GPA:", rs.getString("GPA"));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private static void addInfoRow(JPanel panel, String label, String value) {
        panel.add(new JLabel(label));
        panel.add(new JLabel(value));
    }

    private static DefaultTableModel getStudentEnrollments(int studentId) {
        String[] columns = {"Course ID", "Course Name", "Status", "Enrollment Date"};
        DefaultTableModel model = new DefaultTableModel(columns, 0) {
            @Override
            public Class<?> getColumnClass(int column) {
                return column == 0 ? Integer.class : String.class;
            }
        };

        try (PreparedStatement pstmt = connection.prepareStatement(
                "SELECT c.CourseID, c.CourseName, e.Status, e.EnrollmentDate " +
                        "FROM Enrollment e " +
                        "JOIN Course c ON e.CourseID = c.CourseID " +
                        "WHERE e.StudentID = ?")) {
            pstmt.setInt(1, studentId);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getInt("CourseID"),
                        rs.getString("CourseName"),
                        rs.getString("Status"),
                        rs.getDate("EnrollmentDate")
                });
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return model;
    }

    private static DefaultTableModel getStudentTeachers(int studentId) {
        String[] columns = {"Course ID", "Course Name", "Teacher Name", "Department"};
        DefaultTableModel model = new DefaultTableModel(columns, 0) {
            @Override
            public Class<?> getColumnClass(int column) {
                return column == 0 ? Integer.class : String.class;
            }
        };

        try (PreparedStatement pstmt = connection.prepareStatement(
                "SELECT c.CourseID, c.CourseName, t.FirstName, t.LastName, t.Department " +
                        "FROM Enrollment e " +
                        "JOIN Teaches ts ON e.CourseID = ts.CourseID " +
                        "JOIN Teacher t ON ts.TeacherID = t.TeacherID " +
                        "JOIN Course c ON e.CourseID = c.CourseID " +
                        "WHERE e.StudentID = ?")) {
            pstmt.setInt(1, studentId);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getInt("CourseID"),
                        rs.getString("CourseName"),
                        rs.getString("FirstName") + " " + rs.getString("LastName"),
                        rs.getString("Department")
                });
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return model;
    }
    private static void showCourseEnrollmentDialog(int studentId) {
        JDialog dialog = new JDialog(frame, "Enroll in Courses", true);
        dialog.setSize(600, 400);
        dialog.setLayout(new BorderLayout());

        // Get available courses
        DefaultTableModel availableCoursesModel = getAvailableCourses(studentId);
        JTable coursesTable = new JTable(availableCoursesModel);
        JScrollPane scrollPane = new JScrollPane(coursesTable);

        // Table configuration
        coursesTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        coursesTable.getColumnModel().getColumn(0).setPreferredWidth(100);
        coursesTable.getColumnModel().getColumn(1).setPreferredWidth(300);

        // Control panel
        JPanel controlPanel = new JPanel();
        JButton enrollButton = new JButton("Enroll in Selected Course");
        JButton refreshButton = new JButton("Refresh List");

        enrollButton.addActionListener(e -> {
            int selectedRow = coursesTable.getSelectedRow();
            if(selectedRow == -1) {
                JOptionPane.showMessageDialog(dialog, "Please select a course");
                return;
            }

            int courseId = (int) coursesTable.getValueAt(selectedRow, 0);
            enrollStudentInCourse(studentId, courseId, dialog);
        });

        refreshButton.addActionListener(e -> {
            availableCoursesModel.setRowCount(0);
            DefaultTableModel newModel = getAvailableCourses(studentId);
            coursesTable.setModel(newModel);
        });

        controlPanel.add(enrollButton);
        controlPanel.add(refreshButton);

        dialog.add(scrollPane, BorderLayout.CENTER);
        dialog.add(controlPanel, BorderLayout.SOUTH);
        dialog.setVisible(true);
    }

    private static DefaultTableModel getAvailableCourses(int studentId) {
        String[] columns = {"Course ID", "Course Name", "Credits", "Department"};
        DefaultTableModel model = new DefaultTableModel(columns, 0) {
            @Override
            public Class<?> getColumnClass(int columnIndex) {
                return columnIndex == 0 || columnIndex == 2 ? Integer.class : String.class;
            }
        };

        try (PreparedStatement pstmt = connection.prepareStatement(
                "SELECT c.CourseID, c.CourseName, c.Credits, c.Department " +
                        "FROM Course c " +
                        "WHERE NOT EXISTS (" +
                        "   SELECT 1 FROM Enrollment e " +
                        "   WHERE e.StudentID = ? AND e.CourseID = c.CourseID" +
                        ")")) {
            pstmt.setInt(1, studentId);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getInt("CourseID"),
                        rs.getString("CourseName"),
                        rs.getInt("Credits"),
                        rs.getString("Department")
                });
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return model;
    }

    private static void enrollStudentInCourse(int studentId, int courseId, JDialog parent) {
        try (PreparedStatement pstmt = connection.prepareStatement(
                "INSERT INTO Enrollment (StudentID, CourseID, Status, EnrollmentDate) " +
                        "VALUES (?, ?, 'Enrolled', CURRENT_DATE)")) {
            pstmt.setInt(1, studentId);
            pstmt.setInt(2, courseId);

            int affectedRows = pstmt.executeUpdate();
            if(affectedRows > 0) {
                JOptionPane.showMessageDialog(parent,
                        "Successfully enrolled in course!",
                        "Enrollment Success",
                        JOptionPane.INFORMATION_MESSAGE);
                parent.dispose();
            }
        } catch (SQLIntegrityConstraintViolationException ex) {
            JOptionPane.showMessageDialog(parent,
                    "You're already enrolled in this course!",
                    "Enrollment Error",
                    JOptionPane.ERROR_MESSAGE);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(parent,
                    "Error enrolling in course: " + ex.getMessage(),
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    // Update the createStudentPanel method to include enrollment button
    private static JPanel createTeacherPanel(int teacherId) {
        JPanel panel = new JPanel(new BorderLayout());

        // Create tabbed interface
        JTabbedPane tabbedPane = new JTabbedPane();

        // Students and Marks Tab
        JPanel marksPanel = new JPanel(new BorderLayout());
        JTable studentsTable = new JTable(getTeacherStudents(teacherId));
        JScrollPane scrollPane = new JScrollPane(studentsTable);

        // Update Marks Button
        JButton updateMarksButton = new JButton("Update Marks");
        updateMarksButton.addActionListener(e -> showUpdateMarksDialog(teacherId, studentsTable));

        marksPanel.add(scrollPane, BorderLayout.CENTER);
        marksPanel.add(updateMarksButton, BorderLayout.SOUTH);

        tabbedPane.addTab("Students & Marks", marksPanel);

        // Personal Information Tab
        JPanel infoPanel = new JPanel(new GridLayout(0, 2, 10, 10));
        addTeacherInfo(teacherId, infoPanel);
        tabbedPane.addTab("My Information", infoPanel);

        panel.add(tabbedPane, BorderLayout.CENTER);
        panel.add(createLogoutButton(), BorderLayout.SOUTH);
        return panel;
    }

    private static DefaultTableModel getTeacherStudents(int teacherId) {
        String[] columns = {"Student ID", "Student Name", "Course", "Current Mark"};
        DefaultTableModel model = new DefaultTableModel(columns, 0) {
            @Override
            public Class<?> getColumnClass(int column) {
                return column == 0 || column == 3 ? Integer.class : String.class;
            }
        };

        try (PreparedStatement pstmt = connection.prepareStatement(
                "SELECT s.StudentID, s.FirstName, s.LastName, c.CourseName, e.Marks " +
                        "FROM Enrollment e " +
                        "JOIN Student s ON e.StudentID = s.StudentID " +
                        "JOIN Teaches t ON e.CourseID = t.CourseID " +
                        "JOIN Course c ON e.CourseID = c.CourseID " +
                        "WHERE t.TeacherID = ?")) {

            pstmt.setInt(1, teacherId);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getInt("StudentID"),
                        rs.getString("FirstName") + " " + rs.getString("LastName"),
                        rs.getString("CourseName"),
                        rs.getInt("Marks")
                });
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return model;
    }

    private static void showUpdateMarksDialog(int teacherId, JTable studentsTable) {
        int selectedRow = studentsTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(frame, "Please select a student");
            return;
        }

        int studentId = (int) studentsTable.getValueAt(selectedRow, 0);
        String courseName = (String) studentsTable.getValueAt(selectedRow, 2);

        JDialog dialog = new JDialog(frame, "Update Marks", true);
        dialog.setSize(300, 200);
        dialog.setLayout(new GridLayout(3, 2, 10, 10));

        JLabel studentLabel = new JLabel("Student ID: " + studentId);
        JLabel courseLabel = new JLabel("Course: " + courseName);
        JLabel marksLabel = new JLabel("New Marks:");
        JTextField marksField = new JTextField();

        JButton submitButton = new JButton("Update");
        submitButton.addActionListener(e -> {
            try {
                int newMarks = Integer.parseInt(marksField.getText());
                if (newMarks < 0 || newMarks > 100) {
                    throw new NumberFormatException();
                }

                updateStudentMarks(teacherId, studentId, courseName, newMarks);
                studentsTable.setModel(getTeacherStudents(teacherId));
                dialog.dispose();

            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(dialog, "Please enter valid marks (0-100)");
            }
        });

        dialog.add(studentLabel);
        dialog.add(courseLabel);
        dialog.add(marksLabel);
        dialog.add(marksField);
        dialog.add(new JLabel()); // Empty cell
        dialog.add(submitButton);
        dialog.setVisible(true);
    }

    private static void updateStudentMarks(int teacherId, int studentId, String courseName, int marks) {
        try (PreparedStatement pstmt = connection.prepareStatement(
                "UPDATE Enrollment e " +
                        "JOIN Teaches t ON e.CourseID = t.CourseID " +
                        "JOIN Courses c ON e.CourseID = c.CourseID " +
                        "SET e.Marks = ? " +
                        "WHERE e.StudentID = ? " +
                        "AND c.CourseName = ? " +
                        "AND t.TeacherID = ?")) {

            pstmt.setInt(1, marks);
            pstmt.setInt(2, studentId);
            pstmt.setString(3, courseName);
            pstmt.setInt(4, teacherId);

            int affectedRows = pstmt.executeUpdate();
            if (affectedRows > 0) {
                JOptionPane.showMessageDialog(frame, "Marks updated successfully!");
            } else {
                JOptionPane.showMessageDialog(frame, "Update failed. Check course assignment.");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(frame, "Database error: " + ex.getMessage());
        }
    }

    private static void addTeacherInfo(int teacherId, JPanel panel) {
        try (PreparedStatement pstmt = connection.prepareStatement(
                "SELECT * FROM Teacher WHERE TeacherID = ?")) {
            pstmt.setInt(1, teacherId);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                addInfoRow(panel, "Teacher ID:", rs.getString("TeacherID"));
                addInfoRow(panel, "Name:", rs.getString("FirstName") + " " + rs.getString("LastName"));
                addInfoRow(panel, "Email:", rs.getString("Email"));
                addInfoRow(panel, "Department:", rs.getString("Department"));
                addInfoRow(panel, "Designation:", rs.getString("Designation"));
                addInfoRow(panel, "Qualification:", rs.getString("Qualification"));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
//    private static JPanel createTeacherPanel(int teacherId) {
//        JPanel panel = new JPanel(new BorderLayout());
//
//        // Add tabbed interface
//        JTabbedPane tabbedPane = new JTabbedPane();
//
//        // 1. Marks Management Tab
//        JPanel marksPanel = new JPanel(new BorderLayout());
//        JTable studentsTable = new JTable(getTeacherStudents(teacherId));
//        JButton updateMarksBtn = new JButton("Update Marks");
//
//        updateMarksBtn.addActionListener(e -> {
//            int selectedRow = studentsTable.getSelectedRow();
//            if (selectedRow == -1) return;
//            int studentId = (int) studentsTable.getValueAt(selectedRow, 0);
//            // Open marks dialog
//        });
//
//        marksPanel.add(new JScrollPane(studentsTable), BorderLayout.CENTER);
//        marksPanel.add(updateMarksBtn, BorderLayout.SOUTH);
//
//        // 2. Course Materials Tab
//        JPanel materialsPanel = new JPanel();
//        // Add course materials UI
//
//        tabbedPane.addTab("Student Marks", marksPanel);
//        tabbedPane.addTab("Course Materials", materialsPanel);
//
//        panel.add(tabbedPane, BorderLayout.CENTER);
//        return panel;
//    }
    private static JButton createLogoutButton() {
        JButton button = new JButton("Logout");
        button.addActionListener(e -> {
            cardLayout.show(mainPanel, LOGIN);
            frame.setTitle("School Management System");
        });
        return button;
    }
}
