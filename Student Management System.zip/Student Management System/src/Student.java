public class Student extends User {
    private String studentID;
    private String batch;
    private String GPA;


    public String getStudentID() {
        return studentID;
    }

    public void setStudentID(String studentID) {
        this.studentID = studentID;
    }



    public void setBatch(String batch) {
        this.batch = batch;
    }

    public void setGPA(String GPA) {
        this.GPA = GPA;
    }


    public String getBatch() {
        return batch;
    }

    public String getGPA() {
        return GPA;
    }
}
