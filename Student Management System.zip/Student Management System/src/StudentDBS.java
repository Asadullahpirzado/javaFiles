import java.sql.*;
import java.util.Scanner;

public class StudentDBS {
    // Database credentials
    private static final String URL = "jdbc:mysql://localhost:3306/StudentManagement";
    private static final String USER = "root";  // Change if your MySQL has a different username
    private static final String PASSWORD = "asad";  // Enter your MySQL password if set

    // Method to add a new student
    public static void addStudent(String firstName, String lastName, String email, String phone, String dob, String address, String department , String Batch , String GPA, String password) {
        String query = "INSERT INTO Student (FirstName, LastName, Email, PhoneNumber, DateOfBirth, Address ,Department, Batch, GPA , password) VALUES ( ?, ?, ?, ?, ?, ?, ?, ? , ?)";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, firstName);
            pstmt.setString(2, lastName);
            pstmt.setString(3, email);
            pstmt.setString(4, phone);
            pstmt.setString(5, dob);
            pstmt.setString(6, address);
            pstmt.setString(7,department);
            pstmt.setString(8,Batch);
            pstmt.setString(9,GPA);
            pstmt.setString(10,password);

            pstmt.executeUpdate();
            System.out.println("✅ Student added successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }


    // Method to update student details
    public static void updateStudent(int studentId, String email, String phone, String address , String GPA , String password) {
        String query = "UPDATE Student SET Email = ?, PhoneNumber = ?, Address = ? , GPA = ? ,  password = ? WHERE StudentID = ?";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, email);
            pstmt.setString(2, phone);
            pstmt.setString(3, address);
            pstmt.setString(4, GPA);
            pstmt.setString(5, password);
           // pstmt.setInt(5, studentId);
            int rowsUpdated = pstmt.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("✅ Student updated successfully!");
            } else {
                System.out.println("⚠️ Student not found!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to delete a student
    public static void deleteStudent(int studentId) {
        String query = "DELETE FROM Student WHERE StudentID = ?";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setInt(1, studentId);
            int rowsDeleted = pstmt.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("✅ Student deleted successfully!");
            } else {
                System.out.println("⚠️ Student not found!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to search for a student
    public static void searchStudent(int studentId) {
        String query = "SELECT * FROM Student WHERE StudentID = ?";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setInt(1, studentId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                System.out.println("\n🎓 Student Found:");
                System.out.println("ID: " + rs.getInt("StudentID"));
                System.out.println("Name: " + rs.getString("FirstName") + " " + rs.getString("LastName"));
                System.out.println("Email: " + rs.getString("Email"));
                System.out.println("Phone: " + rs.getString("PhoneNumber"));
                System.out.println("DOB: " + rs.getString("DateOfBirth"));
                System.out.println("Address: " + rs.getString("Address") + "\n");
                System.out.println("Department: " + rs.getString("Department"));
                System.out.println("Batch: " + rs.getString("Batch"));
                System.out.println("GPA: " + rs.getString("GPA"));
                System.out.println("Password: " + rs.getString("Password"));

            } else {
                System.out.println("⚠️ Student not found!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public static void updateStudentMarks(int teacherID, int studentID, int courseID, int marks) {
        String checkSql = "SELECT * FROM Teaches WHERE TeacherID = ? AND CourseID = ?";
        String updateSql = "UPDATE Enrollment SET Marks = ? WHERE StudentID = ? AND CourseID = ?";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement checkStmt = conn.prepareStatement(checkSql);
             PreparedStatement updateStmt = conn.prepareStatement(updateSql)) {

            // Verify if teacher teaches the course
            checkStmt.setInt(1, teacherID);
            checkStmt.setInt(2, courseID);
            ResultSet rs = checkStmt.executeQuery();

            if (rs.next()) {
                updateStmt.setInt(1, marks);
                updateStmt.setInt(2, studentID);
                updateStmt.setInt(3, courseID);

                int rowsAffected = updateStmt.executeUpdate();
                System.out.println(rowsAffected > 0 ? "Marks updated successfully." : "Error: Student not enrolled in this course.");
            } else {
                System.out.println("Error: Teacher is not assigned to this course.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }public static boolean login(int studentID, String password) {
        String sql = "SELECT Password FROM Student WHERE StudentID = ?";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, studentID);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) { // If student exists
                String storedPassword = rs.getString("Password");

                if (storedPassword.equals(password)) {
                    System.out.println("✅ Login Successful! Welcome, Student.");
                    studentDashboard(studentID); // Call dashboard function
                    return true;  // Login successful
                } else {
                    System.out.println("❌ Incorrect Password! Try again.");
                    return false; // Incorrect password
                }
            } else {
                System.out.println("❌ Student ID not found! Please register.");
                return false; // Student ID not found
            }

        } catch (SQLException e) {
            e.printStackTrace();
            return false; // In case of an exception
        }
    }

    // ✅ Student Dashboard
    private static void studentDashboard(int studentID) {
        Scanner input = new Scanner(System.in);
        char isback= 'y';

        while (isback == 'y') {
            System.out.println("\n===== Student Dashboard =====");
            System.out.println("1. View Full Information");
            System.out.println("2. View Marks & Assigned Teachers");
            System.out.println("3. Enroll in a Course");
            System.out.println("4. Logout");
            System.out.print("Choose an option: ");

            int choice = input.nextInt();

            switch (choice) {
                case 1:
                    viewStudentInfo(studentID);
                    break;
                case 2:
                    viewMarksAndTeachers(studentID);
                    break;
                case 3:
                    enrollInCourse(studentID);
                    break;
                case 4:
                    System.out.println("✅ Logged out successfully.");
                    return; // Exit dashboard
                default:
                    System.out.println("❌ Invalid choice! Please try again.");
            }
            System.out.println(" Do you want to continue (y/n)");
            isback = input.next().charAt(0);
        }
    }

    // ✅ 1. View Full Information
    private static void viewStudentInfo() {
        String sql = "SELECT * FROM Student ";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                System.out.println("\n===== Student Information =====");
                System.out.println("🆔 Student ID: " + rs.getInt("StudentID"));
                System.out.println("👤 Name: " + rs.getString("FirstName") + " " + rs.getString("LastName"));
                System.out.println("📧 Email: " + rs.getString("Email"));
                System.out.println("📞 Phone: " + rs.getString("PhoneNumber"));
                System.out.println("📅 DOB: " + rs.getDate("DateOfBirth"));
                System.out.println("🏠 Address: " + rs.getString("Address"));
                System.out.println("🏫 Department: " + rs.getString("Department"));
                System.out.println("🎓 Batch: " + rs.getString("Batch"));
                System.out.println("📊 GPA: " + rs.getDouble("GPA"));
            } else {
                System.out.println("❌ Student not found!");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // ✅ 2. View Marks & Assigned Teachers
    private static void viewMarksAndTeachers(int studentID) {
        String sql = "SELECT Course.CourseID, Course.CourseName, Teacher.FirstName, Teacher.LastName, Enrollment.Marks " +
                "FROM Enrollment " +
                "JOIN Course ON Enrollment.CourseID = Course.CourseID " +
                "JOIN Teaches ON Course.CourseID = Teaches.CourseID " +
                "JOIN Teacher ON Teaches.TeacherID = Teacher.TeacherID " +
                "WHERE Enrollment.StudentID = ?";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, studentID);
            ResultSet rs = pstmt.executeQuery();

            System.out.println("\n===== Marks & Assigned Teachers =====");
            while (rs.next()) {
                System.out.println("📘 Course: " + rs.getString("CourseName") +
                        " | 🏫 Teacher: " + rs.getString("FirstName") + " " + rs.getString("LastName") +
                        " | 📊 Marks: " + rs.getDouble("Marks"));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // ✅ 3. Enroll in a Course
    private static void enrollInCourse(int studentID) {
        Scanner input = new Scanner(System.in);

        // Display available courses
        String courseSql = "SELECT CourseID, CourseName FROM Course";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(courseSql);
             ResultSet rs = pstmt.executeQuery()) {

            System.out.println("\n===== Available Courses =====");
            while (rs.next()) {
                System.out.println("📘 Course ID: " + rs.getInt("CourseID") + " | Course Name: " + rs.getString("CourseName"));
            }

        } catch (SQLException e) {
            e.printStackTrace();
            return;
        }

        // Ask student to enter Course ID
        System.out.print("\nEnter Course ID to Enroll: ");
        int courseID = input.nextInt();

        String enrollSql = "INSERT INTO Enrollment (StudentID, CourseID, Status) VALUES (?, ?, 'Enrolled')";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(enrollSql)) {

            pstmt.setInt(1, studentID);
            pstmt.setInt(2, courseID);

            int rowsInserted = pstmt.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("✅ Successfully Enrolled in Course!");
            } else {
                System.out.println("❌ Enrollment Failed!");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


}


