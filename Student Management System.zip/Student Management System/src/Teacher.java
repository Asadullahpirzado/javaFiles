import java.util.Scanner;
public class Teacher extends User {
   private double salary;
   private String hireDate;
   private String department;
   private String designation;
   private String qualification;

    public String getHireDate() {
        return hireDate;
    }

    public void setHireDate(String hireDate) {
        this.hireDate = hireDate;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }




    public void setDepartment(String department) {
        this.department = department;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public void setQualification(String qualification) {
        this.qualification = qualification;
    }



    public String getQualification() {
        return this.qualification;
    }

    public String getDesignation() {
        return designation;
    }

    public String getDepartment() {
        return department;
    }


    public double getSalary() {
        return salary;
    }
}
