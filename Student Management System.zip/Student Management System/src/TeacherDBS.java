import java.sql.*;
import java.util.Scanner;

public class TeacherDBS {
    // Database credentials
    private static final String URL = "jdbc:mysql://localhost:3306/StudentManagement";
    private static final String USER = "root";  // Change if your MySQL has a different username
    private static final String PASSWORD = "asad";  // Enter your MySQL password if set

    // Method to add a new teacher
    public static void addTeacher(String firstName, String lastName, String email, String phone, String department, String hireDate , double salary, String designation , String qualification , String password) {
        String query = "INSERT INTO Teacher (FirstName, LastName, Email, PhoneNumber, Department, HireDate , salary , designation , qualification , password) VALUES (?, ?, ?, ?, ?, ? , ?, ?, ? ,? )";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, firstName);
            pstmt.setString(2, lastName);
            pstmt.setString(3, email);
            pstmt.setString(4, phone);
            pstmt.setString(5, department);
            pstmt.setString(6, hireDate);
            pstmt.setDouble(7, salary);
            pstmt.setString(8, designation);
            pstmt.setString(9, qualification);
            pstmt.setString(10, password);
            pstmt.executeUpdate();
            System.out.println("✅ Teacher added successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to update teacher details
    public static void updateTeacher(int teacherId, String email, String phone, String department , double salary, String designation , String password ) {
        String query = "UPDATE Teacher SET Email = ?, PhoneNumber = ?, Department = ?, salary = ? , designation = ? , password = ? WHERE TeacherID = ?";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, email);
            pstmt.setString(2, phone);
            pstmt.setString(3, department);
            pstmt.setDouble(4, salary);
            pstmt.setString(5, designation);
            pstmt.setString(6, password);
            int rowsUpdated = pstmt.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("✅ Teacher updated successfully!");
            } else {
                System.out.println("⚠️ Teacher not found!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to delete a teacher
    public static void deleteTeacher(int teacherId) {
        String query = "DELETE FROM Teacher WHERE TeacherID = ?";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setInt(1, teacherId);
            int rowsDeleted = pstmt.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("✅ Teacher deleted successfully!");
            } else {
                System.out.println("⚠️ Teacher not found!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to search for a teacher
    public static void searchTeacher(int teacherId) {
        String query = "SELECT * FROM Teacher WHERE TeacherID = ?";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setInt(1, teacherId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                System.out.println("\n🎓 Teacher Found:");
                System.out.println("ID: " + rs.getInt("TeacherID"));
                System.out.println("Name: " + rs.getString("FirstName") + " " + rs.getString("LastName"));
                System.out.println("Email: " + rs.getString("Email"));
                System.out.println("Phone: " + rs.getString("PhoneNumber"));
                System.out.println("Department: " + rs.getString("Department"));
                System.out.println("Hire Date: " + rs.getString("HireDate") );
                System.out.println("Salary: " + rs.getString("salary"));
                System.out.println("Designation: " + rs.getString("designation"));
                System.out.println("Qualification: " + rs.getString("qualification"));
            } else {
                System.out.println("⚠️ Teacher not found!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public static void viewAllTeachers() {
        String sql = "SELECT * FROM Teacher";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            ResultSet rs = pstmt.executeQuery();

            System.out.println("List of All Teachers:");
            System.out.println("----------------------------------------------------------------------------------------------------------------------");
            System.out.printf("%-5s %-15s %-15s %-25s %-15s %-15s %-15s %-15s %-15s %-10s\n",
                    "ID", "First Name", "Last Name", "Email", "Phone", "Department", "Hire Date", "Salary", "Designation", "Qualification");
            System.out.println("----------------------------------------------------------------------------------------------------------------------");

            while (rs.next()) {
                System.out.printf("%-5d %-15s %-15s %-25s %-15s %-15s %-15s %-15.2f %-15s %-10s\n",
                        rs.getInt("TeacherID"),
                        rs.getString("FirstName"),
                        rs.getString("LastName"),
                        rs.getString("Email"),
                        rs.getString("PhoneNumber"),
                        rs.getString("Department"),
                        rs.getDate("HireDate"),
                        rs.getDouble("Salary"),
                        rs.getString("Designation"),
                        rs.getString("Qualification"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static boolean login(int teacherID, String password) {
        String sql = "SELECT Password FROM Teacher WHERE TeacherID = ?";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, teacherID);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) { // If teacher exists
                String storedPassword = rs.getString("Password");

                if (storedPassword.equals(password)) {
                    System.out.println("✅ Login Successful! Welcome, Teacher.");
                    teacherDashboard(teacherID); // Call dashboard function
                    return true;  // Login successful
                } else {
                    System.out.println("❌ Incorrect Password! Try again.");
                    return false; // Incorrect password
                }
            } else {
                System.out.println("❌ Teacher ID not found! Please register.");
                return false; // Teacher ID not found
            }

        } catch (SQLException e) {
            e.printStackTrace();
            return false; // In case of an exception
        }
    }


    // ✅ Teacher Dashboard: Display Options
    private static void teacherDashboard(int teacherID) {
        Scanner input = new Scanner(System.in);
        char isback= 'y';

        while (isback == 'y') {
            System.out.println("\n===== Teacher Dashboard =====");
            System.out.println("1. View Assigned Courses");
            System.out.println("2. View Enrolled Students");
            System.out.println("3. Update Student Marks");
            System.out.println("4. Logout");
            System.out.print("Choose an option: ");

            int choice = input.nextInt();

            switch (choice) {
                case 1:
                    viewAssignedCourses(teacherID);
                    break;
                case 2:
                    viewEnrolledStudents(teacherID);
                    break;
                case 3:
                    updateStudentMarks(teacherID);
                    break;
                case 4:
                    System.out.println("✅ Logged out successfully.");
                    return; // Exit dashboard
                default:
                    System.out.println("❌ Invalid choice! Please try again.");
            }
            System.out.println(" Do you want to continue (y/n)");
            isback = input.next().charAt(0);
        }
    }

    // ✅ Function to View Assigned Courses
    private static void viewAssignedCourses(int teacherID) {
        String sql = "SELECT Course.CourseID, Course.CourseName FROM Teaches " +
                "JOIN Course ON Teaches.CourseID = Course.CourseID " +
                "WHERE Teaches.TeacherID = ?";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, teacherID);
            ResultSet rs = pstmt.executeQuery();

            System.out.println("\nAssigned Courses:");
            while (rs.next()) {
                System.out.println("📘 Course ID: " + rs.getInt("CourseID") + " | Course Name: " + rs.getString("CourseName"));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // ✅ Function to View Enrolled Students
    private static void viewEnrolledStudents(int teacherID) {
        String sql = "SELECT Student.StudentID, Student.FirstName, Student.LastName " +
                "FROM Enrollment " +
                "JOIN Student ON Enrollment.StudentID = Student.StudentID " +
                "JOIN Teaches ON Enrollment.CourseID = Teaches.CourseID " +
                "WHERE Teaches.TeacherID = ?";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, teacherID);
            ResultSet rs = pstmt.executeQuery();

            System.out.println("\nEnrolled Students:");
            while (rs.next()) {
                System.out.println("👨‍🎓 Student ID: " + rs.getInt("StudentID") +
                        " | Name: " + rs.getString("FirstName") + " " + rs.getString("LastName"));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // ✅ Function to Update Student Marks
    private static void updateStudentMarks(int teacherID) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter Student ID: ");
        int studentID = input.nextInt();

        System.out.print("Enter Course ID: ");
        int courseID = input.nextInt();

        System.out.print("Enter New Marks: ");
        double marks = input.nextDouble();

        String sql = "UPDATE Enrollment SET Marks = ? WHERE StudentID = ? AND CourseID = ? AND CourseID IN " +
                "(SELECT CourseID FROM Teaches WHERE TeacherID = ?)";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setDouble(1, marks);
            pstmt.setInt(2, studentID);
            pstmt.setInt(3, courseID);
            pstmt.setInt(4, teacherID);

            int rowsUpdated = pstmt.executeUpdate();

            if (rowsUpdated > 0) {
                System.out.println("✅ Marks Updated Successfully!");
            } else {
                System.out.println("❌ Update Failed! Check Student ID and Course ID.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
