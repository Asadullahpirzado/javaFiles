import java.sql.*;


public class TeachesDBS {
    private static final String URL = "jdbc:mysql://localhost:3306/StudentManagement";
    private static final String USER = "root";  // Change if your MySQL has a different username
    private static final String PASSWORD = "asad";  // Enter your MySQL password if set

    public static void assignCourseToTeacher(int teacherID, int courseID) {
        String sql = "INSERT INTO Teaches (TeacherID, CourseID) VALUES (?, ?)";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, teacherID);  // Set teacher's ID
            pstmt.setInt(2, courseID);   // Set course's ID

            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Course assigned to teacher successfully.");
            } else {
                System.out.println("Failed to assign course.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void viewAllAssignments() {
        String sql = "SELECT Teacher.FirstName, Teacher.LastName, Course.CourseName " +
                "FROM Teaches " +
                "JOIN Teacher ON Teaches.TeacherID = Teacher.TeacherID " +
                "JOIN Course ON Teaches.CourseID = Course.CourseID";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            ResultSet rs = pstmt.executeQuery();
            System.out.println("Teacher-Course Assignments:");
            System.out.println("-------------------------------------------------");
            System.out.printf("%-15s %-15s %-25s\n", "First Name", "Last Name", "Course Name");
            System.out.println("-------------------------------------------------");

            while (rs.next()) {
                System.out.printf("%-15s %-15s %-25s\n",
                        rs.getString("FirstName"),
                        rs.getString("LastName"),
                        rs.getString("CourseName"));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

    }
    public static void deleteAssignment(int teacherID, int courseID) {
        String sql = "DELETE FROM Teaches WHERE TeacherID = ? AND CourseID = ?";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, teacherID); // Set TeacherID
            pstmt.setInt(2, courseID);  // Set CourseID

            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Assignment deleted successfully.");
            } else {
                System.out.println("No assignment found to delete.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public static void viewTeacherAssignments(int teacherID) {
        String sql = "SELECT Teacher.FirstName, Teacher.LastName, Course.CourseName " +
                "FROM Teaches " +
                "JOIN Teacher ON Teaches.TeacherID = Teacher.TeacherID " +
                "JOIN Course ON Teaches.CourseID = Course.CourseID " +
                "WHERE Teacher.TeacherID = ?";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, teacherID); // Set the TeacherID parameter

            ResultSet rs = pstmt.executeQuery();
            System.out.println("Teacher's Assigned Courses:");
            System.out.println("-------------------------------------------------");
            System.out.printf("%-15s %-15s %-25s\n", "First Name", "Last Name", "Course Name");
            System.out.println("-------------------------------------------------");

            while (rs.next()) {
                System.out.printf("%-15s %-15s %-25s\n",
                        rs.getString("FirstName"),
                        rs.getString("LastName"),
                        rs.getString("CourseName"));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

